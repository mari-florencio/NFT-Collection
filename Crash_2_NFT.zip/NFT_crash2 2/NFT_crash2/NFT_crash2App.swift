//
//  NFT_crash2App.swift
//  NFT_crash2
//
//  Created by Mariana Florencio on 28/09/21.
//

import SwiftUI

@main
struct NFT_crash2App: App {
   
    init() {
        UINavigationBar.appearance().largeTitleTextAttributes = [.foregroundColor : UIColor.white]
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
           
        }
    }
}
