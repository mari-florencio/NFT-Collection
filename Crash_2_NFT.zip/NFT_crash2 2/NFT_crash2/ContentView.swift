//
//  ContentView.swift
//  NFT_crash2
//
//  Created by Mariana Florencio on 28/09/21.
//

import SwiftUI
import CoreData

struct ContentView: View {
    
    var appModel: AppModel = AppModel()
    
    var body: some View {
        NavigationView {
            
            VStack {
                
                VStack {
                    
                    Image("foto1")
                    //   .offset(y: -10)
                    
                    Text(appModel.homeScreen.name)
                        .foregroundColor(.white)
                        .font(.title)
                        .fontWeight(.heavy)
                    
                    HStack {
                        
                        ZStack {
                            Text(appModel.homeScreen.user)
                                .foregroundColor(.white)
                            
                            Rectangle()
                                .frame(width: 75, height: 25)
                                .cornerRadius(20)
                                .foregroundColor(.white)
                                .opacity(0.3)
                        }
                        
                        ZStack {
                            Text(appModel.homeScreen.wallet)
                                .foregroundColor(.white)
                            
                            Rectangle()
                                .frame(width: 140, height: 25)
                                .cornerRadius(20)
                                .foregroundColor(.white)
                                .opacity(0.3)
                        }
                    }// .padding(.bottom)
                    
                    Rectangle()
                        .frame(width: 300, height: 1)
                        .cornerRadius(20)
                        .foregroundColor(.white)
                        .opacity(0.3)
                        .padding()
                    
                    
                    
                    HStack  {
                        
                        Image(systemName: "sparkles")
                            .foregroundColor(.white)
                            .font(.system(size: 22, weight: .bold, design: .default))
                        
                        Text("your NFTs")
                            .font(.system(size: 20, weight: .bold, design: .default))
                            .foregroundColor(.white)
                        
                        
                    } .frame(maxWidth: 340, alignment: .leading)
                    
                    
                    
                    
                } //your NFTs
                
                
                HStack {
                    Image("img1")
                    Image("img2")
                }
                
                HStack {
                    Image("img3")
                    Image("img4")
                    
                } .padding()
                
                
                NavigationLink(destination: CoverCollection(informations: appModel.homeScreen.informations), label: {
                    
                    Text("See All")
                        .bold()
                        .frame(width: 332, height: 50)
                        .background(Color.white)
                        .foregroundColor(.black)
                        .cornerRadius(10)
                    
                })
                
                // Image("btn")
                
             
            }
            .navigationBarHidden(true)
            
            .background(Image("bg3"))
            .scaledToFill()
            .fixedSize()
            .edgesIgnoringSafeArea(.all)
            
        }
        
    }
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
