//
//  AppModel.swift
//  NFT_crash2
//
//  Created by Mariana Florencio on 02/10/21.
//

import Foundation

class AppModel: ObservableObject {

    var homeScreen: HomeScreen = HomeScreen(
        name: "Mariana Florencio", user: "@florz", wallet: "0s4r63...2f45",
        
        informations: [
            InformationNFT(id: UUID().uuidString, image: "img1", name: "Mystical melt", properties: "rare", description: "The most abstract NFT collection of all time! 1000 NFTS are made from a combination of over 200 inks, hand-drawn in a specific color mixing technique. The Mystical Melts are active in the Ethereum blockchain in the form of ERC-721 tokens.", creator: "Florence"),
            
            InformationNFT(id: UUID().uuidString, image: "img2", name: "Duck", properties: "rare", description: "The most abstract NFT collection of all time! 1000 NFTS are made from a combination of over 200 inks, hand-drawn in a specific color mixing technique. The Mystical Melts are active in the Ethereum blockchain in the form of ERC-721 tokens.", creator: "Florence"),
            
            InformationNFT(id: UUID().uuidString, image: "img3", name: "Kong", properties: "rare", description: "The most abstract NFT collection of all time! 1000 NFTS are made from a combination of over 200 inks, hand-drawn in a specific color mixing technique. The Mystical Melts are active in the Ethereum blockchain in the form of ERC-721 tokens.", creator: "Florence"),
            
            InformationNFT(id: UUID().uuidString, image: "img4", name: "Crazy NFT", properties: "rare", description: "The most abstract NFT collection of all time! 1000 NFTS are made from a combination of over 200 inks, hand-drawn in a specific color mixing technique. The Mystical Melts are active in the Ethereum blockchain in the form of ERC-721 tokens.", creator: "Florence"),
            
            InformationNFT(id: UUID().uuidString, image: "img5", name: "Mystical melt", properties: "rare", description: "The most abstract NFT collection of all time! 1000 NFTS are made from a combination of over 200 inks, hand-drawn in a specific color mixing technique. The Mystical Melts are active in the Ethereum blockchain in the form of ERC-721 tokens.", creator: "Florence"),
            
            InformationNFT(id: UUID().uuidString, image: "img6", name: "Mystical melt", properties: "rare", description: "The most abstract NFT collection of all time! 1000 NFTS are made from a combination of over 200 inks, hand-drawn in a specific color mixing technique. The Mystical Melts are active in the Ethereum blockchain in the form of ERC-721 tokens.", creator: "Florence"),
            
            InformationNFT(id: UUID().uuidString, image: "img7", name: "Mystical melt", properties: "rare", description: "The most abstract NFT collection of all time! 1000 NFTS are made from a combination of over 200 inks, hand-drawn in a specific color mixing technique. The Mystical Melts are active in the Ethereum blockchain in the form of ERC-721 tokens.", creator: "Florence"),
            
            InformationNFT(id: UUID().uuidString, image: "img8", name: "Mystical melt", properties: "rare", description: "The most abstract NFT collection of all time! 1000 NFTS are made from a combination of over 200 inks, hand-drawn in a specific color mixing technique. The Mystical Melts are active in the Ethereum blockchain in the form of ERC-721 tokens.", creator: "Florence"),
            
            InformationNFT(id: UUID().uuidString, image: "img9", name: "Mystical melt", properties: "rare", description: "The most abstract NFT collection of all time! 1000 NFTS are made from a combination of over 200 inks, hand-drawn in a specific color mixing technique. The Mystical Melts are active in the Ethereum blockchain in the form of ERC-721 tokens.", creator: "Florence"),
            
            InformationNFT(id: UUID().uuidString, image: "img10", name: "Mystical melt", properties: "rare", description: "The most abstract NFT collection of all time! 1000 NFTS are made from a combination of over 200 inks, hand-drawn in a specific color mixing technique. The Mystical Melts are active in the Ethereum blockchain in the form of ERC-721 tokens.", creator: "Florence"),
            
            InformationNFT(id: UUID().uuidString, image: "img11", name: "Mystical melt", properties: "rare", description: "The most abstract NFT collection of all time! 1000 NFTS are made from a combination of over 200 inks, hand-drawn in a specific color mixing technique. The Mystical Melts are active in the Ethereum blockchain in the form of ERC-721 tokens.", creator: "Florence"),
            
            InformationNFT(id: UUID().uuidString, image: "img12", name: "Mystical melt", properties: "rare", description: "The most abstract NFT collection of all time! 1000 NFTS are made from a combination of over 200 inks, hand-drawn in a specific color mixing technique. The Mystical Melts are active in the Ethereum blockchain in the form of ERC-721 tokens.", creator: "Florence"),
            
            InformationNFT(id: UUID().uuidString, image: "img13", name: "Mystical melt", properties: "rare", description: "The most abstract NFT collection of all time! 1000 NFTS are made from a combination of over 200 inks, hand-drawn in a specific color mixing technique. The Mystical Melts are active in the Ethereum blockchain in the form of ERC-721 tokens.", creator: "Florence"),
            
            InformationNFT(id: UUID().uuidString, image: "img14", name: "Mystical melt", properties: "rare", description: "The most abstract NFT collection of all time! 1000 NFTS are made from a combination of over 200 inks, hand-drawn in a specific color mixing technique. The Mystical Melts are active in the Ethereum blockchain in the form of ERC-721 tokens.", creator: "Florence"),
            
            InformationNFT(id: UUID().uuidString, image: "img15", name: "Mystical melt", properties: "rare", description: "The most abstract NFT collection of all time! 1000 NFTS are made from a combination of over 200 inks, hand-drawn in a specific color mixing technique. The Mystical Melts are active in the Ethereum blockchain in the form of ERC-721 tokens.", creator: "Florence"),
            
            InformationNFT(id: UUID().uuidString, image: "img16", name: "Mystical melt", properties: "rare", description: "The most abstract NFT collection of all time! 1000 NFTS are made from a combination of over 200 inks, hand-drawn in a specific color mixing technique. The Mystical Melts are active in the Ethereum blockchain in the form of ERC-721 tokens.", creator: "Florence")]
        
        )
}
