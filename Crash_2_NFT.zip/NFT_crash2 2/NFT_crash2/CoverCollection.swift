//
//  CoverCollection.swift
//  NFT_crash2
//
//  Created by Mariana Florencio on 03/10/21.
//

import SwiftUI

struct CoverCollection: View {
    
    var informations: [InformationNFT]

    var body: some View {
        
        ScrollView {
        
            LazyVGrid(columns: [GridItem(), GridItem()], alignment: .center, spacing: 20)
            {
                ForEach(informations) { info  in CoverNFT(info: info)
                }
                
            
            }
 .navigationBarTitle("My collection")
        .foregroundColor(Color.white)
        .background(Image("bg3"))
            .scaledToFill()
            .edgesIgnoringSafeArea(.all)
        }
    }
}

struct CoverCollection_Previews: PreviewProvider {
    static var previews: some View {
        CoverCollection(informations: AppModel().homeScreen.informations)
    }
}
