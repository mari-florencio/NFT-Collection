////
////  CollectionWrong.swift
////  NFT_crash2
////
////  Created by Mariana Florencio on 03/10/21.
////
//
//import SwiftUI
//
//struct CollectionOld: View {
//    var body: some View {
//        
//        ScrollView {
//                    VStack {
//        
//                        HStack {
//                            Image("img1")
//                            Image("img2")
//                        }
//        
//                        HStack {
//                            Image("img3")
//                            Image("img4")
//        
//                        }
//                        HStack {
//                            Image("img5")
//                            Image("img6")
//        
//                        }
//                        HStack {
//                            Image("img7")
//                            Image("img8")
//        
//                        }
//                        HStack {
//                            Image("img9")
//                            Image("img10")
//        
//                        }
//                        HStack {
//                            Image("img11")
//                            Image("img12")
//        
//                        }
//                        HStack {
//                            Image("img13")
//                            NavigationLink(destination: ArtView(), label: {
//                                Image("img14")
//        
//        
//                            })
//                        }
//                        .navigationBarTitle("My collection")
//                        .foregroundColor(Color.white)
//                        
//                    }
//                    
//                    
//                    
//    } .frame(width: 500, height: 660)
//        
//            .background(Image("bg3"))
//            .scaledToFill()
//            .fixedSize()
//            .edgesIgnoringSafeArea(.all)
//    }
//      
//        
//       
//}
//
//struct CollectionOld_Previews: PreviewProvider {
//    static var previews: some View {
//        CollectionOld()
//    }
//}
