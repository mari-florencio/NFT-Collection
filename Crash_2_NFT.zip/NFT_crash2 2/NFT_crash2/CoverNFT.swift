//
//  CoverNFT.swift
//  NFT_crash2
//
//  Created by Mariana Florencio on 03/10/21.
//

import SwiftUI

struct CoverNFT: View {
    
    var info: InformationNFT
    var body: some View {
        
    //fazer essa navigation link funcionar direito!!! chamar as infos de cada nft quando clicadas 😠 -> problema com os parametros (acho)
        
        NavigationLink(destination: ArtView(), label: {
            
            VStack(alignment: .center) {
                Image(info.image)
                    .padding(.top)
                //                .resizable()
                //                .frame(width: 165, height: 165, alignment: .center)
                
            }
            
        })
    }
    
}

struct CoverNFT_Previews: PreviewProvider {
    static var previews: some View {
        CoverNFT(info: AppModel().homeScreen.informations[0])
    }
}
