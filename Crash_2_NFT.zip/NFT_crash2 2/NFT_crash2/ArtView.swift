//
//  ArtView.swift
//  NFT_crash2
//
//  Created by Mariana Florencio on 03/10/21.
//

import SwiftUI

struct ArtView: View {
    var body: some View {
         
        
        VStack (alignment: .leading, spacing: 15) {
            Image("fullimg")
                .resizable()
                .scaledToFill()
                .edgesIgnoringSafeArea(.top)
                .frame(width: 350, height: 460, alignment: .center)
            
            HStack {
                
                Text("Mystical melt")
                    .font(.system(size: 32, weight: .bold, design: .default))
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity, alignment: .leading)
                
                ZStack {
                    HStack {
                        Image ("eth")
                        Text("2,55")
                            .font(.system(size: 18, weight: .regular, design: .default))
                            .foregroundColor(.white)
                    }
                    Rectangle()
                        .frame(width: 86, height: 34)
                        .cornerRadius(40)
                        .foregroundColor(.white)
                        .opacity(0.3)
                }
                
            } .padding(.bottom, 5)
            HStack {
                ZStack {
                    Text("glitter \(Text("1/10").fontWeight(.regular))")
                        .font(.system(size: 16, weight: .bold, design: .default))
                        .foregroundColor(.white)
                    Rectangle()
                        .frame(width: 110, height: 30)
                        .foregroundColor(.white)
                        .opacity(0)
                        .cornerRadius(40)
                        .overlay(Capsule(style: .continuous)
                                    .stroke(Color.white, lineWidth: 1))
                }
                
                ZStack {
                    Text("abstract \(Text("2/10").fontWeight(.regular))")
                        .font(.system(size: 16, weight: .bold, design: .default))
                        .foregroundColor(.white)
                    Rectangle()
                        .frame(width: 130, height: 30)
                        .foregroundColor(.white)
                        .opacity(0)
                        .cornerRadius(40)
                        .overlay(Capsule(style: .continuous)
                                    .stroke(Color.white, lineWidth: 1))
                }
                
                ZStack {
                    Text("fluid \(Text("7/10").fontWeight(.regular))")
                        .font(.system(size: 16, weight: .bold, design: .default))
                        .foregroundColor(.white)
                    Rectangle()
                        .frame(width: 95, height: 30)
                        .foregroundColor(.white)
                        .opacity(0)
                        .cornerRadius(40)
                        .overlay(Capsule(style: .continuous)
                                    .stroke(Color.white, lineWidth: 1))
                }
                
                
            }
            VStack (alignment: .leading, spacing: 10){
                HStack {
                    ZStack {
                        Text("digital art \(Text("8/10").fontWeight(.regular))")
                            .font(.system(size: 16, weight: .bold, design: .default))
                            .foregroundColor(.white)
                        Rectangle()
                            .frame(width: 140, height: 30)
                            .foregroundColor(.white)
                            .opacity(0)
                            .cornerRadius(40)
                            .overlay(Capsule(style: .continuous)
                                        .stroke(Color.white, lineWidth: 1))
                        
                    }
                    
                    ZStack {
                        Text("rarity \(Text("3/10").fontWeight(.regular))")
                            .font(.system(size: 16, weight: .bold, design: .default))
                            .foregroundColor(.white)
                        Rectangle()
                            .frame(width: 100, height: 30)
                            .foregroundColor(.white)
                            .opacity(0)
                            .cornerRadius(40)
                            .overlay(Capsule(style: .continuous)
                                        .stroke(Color.white, lineWidth: 1))
                    }
                }
                Text ("The most abstract NFT collection of all time! 1000 NFTS are made from a combination of over 200 inks, hand-drawn in a specific color mixing technique. The Mystical Melts are active in the Ethereum blockchain in the form of ERC-721 tokens.")
                    .frame(width: 350, height: 100, alignment: .leading)
                    .font(.system(size: 14, weight: .regular, design: .default))
                    .foregroundColor(.white)
                
            }
            
            HStack {
                Image("clip")
                Text("Created by \nFlorence")
                    .font(.system(size: 13, weight: .regular, design: .default))
                    .foregroundColor(.white)
                
            }
        }
        .background(Image("bg3"))
        .scaledToFill()
        .fixedSize()
        .edgesIgnoringSafeArea(.all)
    }
    
    
}

struct ArtView_Previews: PreviewProvider {
    static var previews: some View {
        ArtView()
    }
}
