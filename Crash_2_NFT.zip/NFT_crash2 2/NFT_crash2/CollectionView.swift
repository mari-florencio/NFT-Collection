
//  CollectionView.swift
//  NFT_crash2
//
//  Created by Mariana Florencio on 01/10/21.

import SwiftUI
import CoreData

struct CollectionView: View {
        
    var appModel: AppModel = AppModel()
    
    var body: some View {
        NavigationView {
            
            ScrollView {
                VStack{
                    
            CoverCollection(informations: appModel.homeScreen.informations)
                .navigationBarTitle("My collection")
                
                }
            }
            }
        
            
            .background(Image("bg3"))
            .scaledToFill()
            .fixedSize()
            .edgesIgnoringSafeArea(.all)
            
        }

        
        
    }
    
    struct CollectionView_Previews: PreviewProvider {
        static var previews: some View {
            CollectionView()
        }
    }

