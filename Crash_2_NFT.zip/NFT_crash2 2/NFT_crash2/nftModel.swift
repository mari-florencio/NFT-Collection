//
//  nftModel.swift
//  NFT_crash2
//
//  Created by Mariana Florencio on 02/10/21.
//

import Foundation

struct InformationNFT: Identifiable {
    var id: String
    let image: String
    let name: String
    let properties: String
    let description: String
    let creator: String
}

struct HomeScreen {
    let name: String
    let user: String
    let wallet: String
    let informations: [InformationNFT]
}
